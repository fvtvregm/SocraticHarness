# AGENTS.md - Open Sunsama

AI-agent-friendly task management + time blocking app. TypeScript monorepo with Bun, Turborepo, PostgreSQL, Drizzle ORM.

Follow [DESIGN.md](DESIGN.md) for the compact workspace design tokens, component measurements, themes, and interaction rules.

## Testing

**Use Cursor browser tool for UI testing.**

| Environment | Web                     | API                         | Prerequisites                          |
| ----------- | ----------------------- | --------------------------- | -------------------------------------- |
| Local       | http://localhost:3000   | http://localhost:3001       | `bun run dev:local` (see below)        |
| Production  | https://opensunsama.com | https://api.opensunsama.com | None                                   |

**Login credentials:** `.env.local` in project root (gitignored, real user account - NEVER commit).

### Local dev and testing: no Docker

**Never use Docker to develop or test.** No `docker run`, no `docker compose`, no local Postgres or Redis containers. The Docker VM slows the laptop and fills the disk. Run plain dev servers against the shared dev database instead:

- **`bun run dev:local`** starts the API on :3001 and the web app on :3000. They use `dev-postgres`, the only service in Railway's `development` environment, and migrations run on start. Set `API_PORT` and `WEB_PORT` to run several worktrees side by side.
- **In the browser pane,** use `preview_start` with the `.claude/launch.json` configs: `api` + `web` (3001/3000), or `api-demo` + `web-demo` (3101/3107) for demo recordings.
- **Never start a local API from `apps/api/.env`.** That file points at the production database and Redis. `scripts/dev-local.mjs` passes every variable explicitly, blanks Redis, email, background jobs, S3 and OAuth, and refuses the production database.
- **The dev database is shared and disposable.** Register throwaway users (`<name>-e2e@example.com`) through the API instead of touching real accounts. It runs Postgres 18; production runs 17.
- **`docker-compose.yml` and the Dockerfiles exist for self-hosters.** Check changes to them in CI or on Railway, not with a local Docker.

**MCP Tool:** Use `open-sunsama` MCP server to create/update tasks, time blocks, subtasks programmatically.

### Shipping a change (agents)

- **Review and merge your own PR.** Read your full diff for bugs, fix what you find, wait for CI (`gh pr checks <N> --watch`), then merge it yourself.
- **CI is required on main.** `.github/workflows/ci.yml` runs two checks on every PR, and a ruleset blocks merging until both pass:
  - **Checks:** install with a frozen lockfile, typecheck, lint, unit tests, build, migrations match the schema, and the desktop bundle stays under 60 MB.
  - **End-to-end:** a fresh Postgres, the built API and the web app, then the Playwright smoke tests in `e2e/` and the MCP OAuth suite.
- **Nobody can skip CI, admins included.** Direct pushes to main are rejected; open a PR. If CI itself is wrong, fix CI in its own PR.
- **Run the end-to-end tests locally** against a local database (never production): migrate it, then `DATABASE_URL=<local url> e2e/start-stack.sh && bun run e2e`. The stack uses ports 3201 (API) and 3207 (web).
- **Validate in production before calling it done.** After the deploy, prove the change works end to end: check `railway logs --service api` for errors, query the data read-only, and test anything a user can see in the browser pane on https://opensunsama.com. An open PR or passing tests is not done.

---

## Structure

```
opensunsama/
├── apps/
│   ├── api/        # Hono REST API (port 3001)
│   ├── web/        # React + Vite SPA (port 3000)
│   ├── desktop/    # Tauri v2 wrapper
│   └── mobile/     # Expo React Native
├── packages/
│   ├── database/   # Drizzle ORM + PostgreSQL
│   ├── types/      # Shared TypeScript types
│   ├── api-client/ # HTTP client + React Query hooks
│   └── utils/      # Date, validation, errors
├── mcp/            # MCP server for AI agents
└── .todo/          # PRD documents
```

---

## Apps

### API (`apps/api`)

**Hono v4** | Port 3001 | tsup build

| Route                   | Auth  | Description                      |
| ----------------------- | ----- | -------------------------------- |
| `/auth/*`               | Mixed | Login, register, profile         |
| `/tasks/*`              | Yes   | Task CRUD + reorder              |
| `/tasks/:id/subtasks/*` | Yes   | Subtask CRUD                     |
| `/time-blocks/*`        | Yes   | Time block CRUD + cascade resize |
| `/calendar-events`      | Yes   | Synced events (`date` or `from`/`to`; `calendar:read`) |
| `/api-keys/*`           | JWT   | API key management               |
| `/mcp`                  | OAuth/API key | Remote MCP server (Streamable HTTP) |
| `/oauth/*`, `/.well-known/*` | Mixed | OAuth 2.1 for MCP clients     |
| `/uploads/*`            | Yes   | S3 file uploads                  |

**Auth:** JWT (`Bearer <token>`), API Key (`X-API-Key: os_<key>`), or MCP OAuth token (`Bearer osat_<token>`)  
**Scopes:** `tasks:read`, `tasks:write`, `time-blocks:read`, `time-blocks:write`, `calendar:read`, `user:read`, `user:write`

### Web (`apps/web`)

**React 19 + Vite** | TanStack Router + Query | Radix UI + Tailwind | Port 3000

| Route                | Description       |
| -------------------- | ----------------- |
| `/app`               | Main kanban board |
| `/app/calendar`      | Timeline view     |
| `/app/focus/$taskId` | Focus mode        |
| `/app/settings`      | User settings     |

**Features:** Kanban drag-drop (@dnd-kit), time blocking, focus mode with timer, command palette (Cmd+K), rich text (Tiptap), file attachments, WebSocket sync.

**MDX Blog:** Uses `@mdx-js/rollup` + `remark-gfm` for GFM support (tables, strikethrough, task lists). Config in `vite.config.ts`.

### Desktop (`apps/desktop`)

**Tauri v2** | System tray, global hotkeys (Cmd+Shift+T), notifications, auto-launch.

### Mobile (`apps/mobile`)

**Expo 52** | Expo Router | Tab navigation (Tasks, Calendar, Settings).

---

## Database

**PostgreSQL + Drizzle ORM**

| Table                      | Purpose                                                 |
| -------------------------- | ------------------------------------------------------- |
| `users`                    | Accounts with preferences (JSONB)                       |
| `tasks`                    | Title, notes, scheduledDate, priority (P0-P3), position |
| `subtasks`                 | Checklist items per task                                |
| `time_blocks`              | Scheduled blocks linked to tasks                        |
| `api_keys`                 | Hashed keys with scopes                                 |
| `attachments`              | S3 file metadata                                        |
| `notification_preferences` | Reminders, rollover settings                            |

**Relations:** Users → Tasks → Subtasks (CASCADE), Tasks ↔ TimeBlocks (SET NULL), Tasks → Attachments (CASCADE)

**Migrations:** `packages/database/drizzle` starts at `0000_baseline`, a squash of the old 0000–0016 with the old 0016's journal timestamp, so databases that already ran those skip it. Every statement is `IF NOT EXISTS`, so it also runs cleanly on a database built with `db:push`. After a schema change, run `bun run db:generate` and commit the SQL. The API applies migrations on start when `MIGRATE_ON_START=true` (the self-host `docker-compose.yml` sets it; production doesn't), or with `node dist/migrate.js`.

**Self-hosting:** `docker compose up -d --build` builds and starts PostgreSQL, Redis, the API and the web app (`docker compose up -d postgres` for the database alone). Guide: `apps/web/src/content/docs/self-hosting/docker.mdx`.

---

## MCP (24 tools)

Two ways in, same tools (`mcp/src/tools`, shared via `@open-sunsama/mcp/server`):

- **Remote (recommended):** `https://api.opensunsama.com/mcp`, Streamable HTTP served by the API (`apps/api/src/routes/mcp.ts`). Auth is OAuth 2.1 from the API's own authorization server (`apps/api/src/routes/oauth.ts`, `lib/oauth/*`, tables `oauth_clients`/`oauth_authorization_codes`/`oauth_tokens`). The consent screen is the web route `/oauth/consent`. API keys also work (`X-API-Key` or `Bearer os_...`).
- **Local stdio:** `npx @open-sunsama/mcp` with `OPENSUNSAMA_API_KEY`.

E2E test of the OAuth flow against a local API: `MCP_E2E_API_URL=http://localhost:3001 bun run mcp/tests/oauth-e2e.ts`.

| Category    | Tools                                                                                                                                                  |
| ----------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Tasks       | `list_tasks`, `get_task`, `create_task`, `update_task`, `complete_task`, `uncomplete_task`, `delete_task`, `schedule_task`, `reorder_tasks`            |
| Time Blocks | `list_time_blocks`, `get_time_block`, `create_time_block`, `update_time_block`, `delete_time_block`, `link_task_to_time_block`, `get_schedule_for_day` |
| Calendar    | `list_calendar_events` (read-only events synced from Google/Outlook/iCloud; also shown in `get_schedule_for_day`)                                   |
| Subtasks    | `list_subtasks`, `create_subtask`, `toggle_subtask`, `update_subtask`, `delete_subtask`                                                                |
| User        | `get_user_profile`, `update_user_profile`                                                                                                              |

---

## Commands

```bash
bun install          # Install deps
bun dev              # Start all dev servers
bun run build        # Build all
bun run typecheck    # Type check
bun run lint         # Lint
bun run test         # Tests
bun run e2e          # Browser smoke tests (needs e2e/start-stack.sh running; locally, point it at dev-postgres — see the script header)

# Database
bun run db:generate  # Generate migrations
bun run db:migrate   # Run migrations
bun run db:push      # Push schema (scratch databases only; skips the migration history)
bun run db:studio    # Drizzle Studio

# Per-app
bun run --filter=@open-sunsama/api dev
bun run --filter=@open-sunsama/web dev
```

---

## API Response Format

```json
// Success
{ "success": true, "data": {...}, "meta": { "page": 1, "total": 100 } }

// Error
{ "success": false, "error": { "code": "VALIDATION_ERROR", "message": "...", "statusCode": 400 } }
```

---

## Environment

**API** (`apps/api/.env`): `DATABASE_URL`, `JWT_SECRET`, `PORT`, `CORS_ORIGIN`, S3 vars, VAPID keys, `RESEND_API_KEY`

**Web** (`apps/web/.env`): `VITE_API_URL`

**Root** (`.env.local`): Test credentials (gitignored)

---

## Versioning

**See [`.skills/versioning/SKILL.md`](.skills/versioning/SKILL.md) for complete versioning guide.**

Quick reference:

- **Source of truth:** `package.json` (root)
- **Sync command:** `bun run version:sync`
- **Current version:** v1.2.5

---

## Desktop Releases

**See [`.skills/desktop-releases/SKILL.md`](.skills/desktop-releases/SKILL.md) for complete release guide.**

Quick reference:

- **Release:** `bun run release` (bumps and syncs the version, merges it through a PR once CI passes, then tags and pushes the tag; about 15 minutes to all platforms)
- **Manual trigger:** GitHub → Actions → Desktop Release → Run workflow
- **Downloads page:** https://opensunsama.com/download
- **Platforms:** macOS (arm64/x64), Windows, Linux

### Release rules (enforced by CI)

- **The desktop app bundles the web app.** A web change reaches desktop users only after the next release. Ship with `bun run release`, never by hand-tagging: the build fails if the tag doesn't match `apps/desktop/src-tauri/tauri.conf.json`.
- **Keep large files out of the desktop bundle.** `apps/desktop/scripts/prepare-frontend.mjs` drops marketing images (`blog-*`, `landing/`, `og-image.png`) and fails the build if the rest passes 60 MB. If it fails, exclude or shrink the new files; don't raise the limit. Oversized bundles once made each installer 600 MB and the Linux build 5 hours.
- **A release is done when the `verify` job is green.** It checks that all four platforms serve the new version and that each download and updater URL returns HTTP 200. If one platform fails, use **Re-run failed jobs**; re-runs are safe.

### macOS Code Signing

**Apple Developer Account:** Circo, Inc.
**Team ID:** `DQVMM49PG9`
**Apple ID:** `kai.jiabo.feng@gmail.com`

GitHub Secrets required for signing:

- `APPLE_CERTIFICATE` - Base64-encoded .p12 certificate
- `APPLE_CERTIFICATE_PASSWORD` - Password for .p12
- `KEYCHAIN_PASSWORD` - Random string for CI keychain
- `APPLE_ID` - Apple Developer email
- `APPLE_PASSWORD` - App-specific password (from appleid.apple.com)
- `APPLE_TEAM_ID` - `DQVMM49PG9`

### Tauri v2 Entitlements (Critical)

**Key Insight:** When macOS apps are signed with **Hardened Runtime** (required for notarization), entitlements MUST be explicitly embedded during signing or the app will fail to make network requests.

**Symptoms of missing entitlements:**

- App works in dev mode but fails in production signed builds
- "Login failed" or network errors in signed/notarized builds
- `codesign -d --entitlements -` shows empty output on signed app

**Required config in `tauri.conf.json`:**

```json
{
  "bundle": {
    "macOS": {
      "entitlements": "./Entitlements.plist",
      "hardenedRuntime": true
    }
  }
}
```

**Required `Entitlements.plist` for network access:**

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "...">
<plist version="1.0">
<dict>
    <key>com.apple.security.app-sandbox</key>
    <false/>
    <key>com.apple.security.network.client</key>
    <true/>
</dict>
</plist>
```

**Verify entitlements are embedded:**

```bash
codesign -d --entitlements - "App.app"
# Should show network.client = true
```

---

## Railway Debugging

**Railway CLI** is installed. Use it to check services, environment variables, and logs.

### Quick Commands

```bash
# Check login status
railway whoami

# Check current project/service
railway status

# List environment variables for a service
railway variables --service api
railway variables --service Postgres

# The development environment holds only dev-postgres (the local dev database).
# Keep checkouts linked to production and pass -e for dev:
railway variables -e development -s dev-postgres

# View logs (streams live)
railway logs --service api
```

### Database Access

The Postgres MCP tool points to a different project. To query the Open Sunsama database directly:

```bash
# Get public DATABASE_URL
railway variables --service Postgres | grep DATABASE_PUBLIC_URL

# Run queries using the public URL
DATABASE_URL="postgresql://postgres:PASSWORD@ballast.proxy.rlwy.net:29435/railway" node -e "
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
// ... your query
"
```

---

## PG Boss (Background Jobs)

Task rollover, daily summaries, and task reminders use PG Boss for job scheduling.

### Health Check

```bash
curl https://api.opensunsama.com/health
# Should show: "pgBossRunning": true
```

### Debugging PG Boss Issues

1. **Check health endpoint** - shows `pgBossRunning` status and any initialization errors
2. **Check pgboss.schedule table** - should have `timezone-rollover-check`, `daily-summary-check`, `task-reminder-check`
3. **Check pgboss.job table** - recent jobs and their states
4. **Check rollover_logs table** - rollover history and errors

```bash
# Check PG Boss state in database
DATABASE_URL="..." node -e "
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
async function check() {
  const client = await pool.connect();
  const schedules = await client.query('SELECT name, cron FROM pgboss.schedule');
  console.log('Scheduled jobs:', schedules.rows);
  const jobs = await client.query('SELECT name, state, created_on FROM pgboss.job ORDER BY created_on DESC LIMIT 10');
  console.log('Recent jobs:', jobs.rows);
  const logs = await client.query('SELECT * FROM rollover_logs ORDER BY executed_at DESC LIMIT 5');
  console.log('Rollover logs:', logs.rows);
  client.release();
  await pool.end();
}
check();
"
```

### Manual Rollover

If PG Boss isn't running, use the manual rollover endpoint:

```bash
curl -X POST https://api.opensunsama.com/tasks/rollover \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### Automatic Recovery

PG Boss has built-in recovery mechanisms:

1. **Watchdog** - Checks every 60 seconds if PG Boss died and attempts recovery (up to 5 attempts)
2. **Health check** - Returns `503` if PG Boss is dead, triggering Railway to restart the container
3. **Event listener** - Detects when PG Boss stops unexpectedly and marks for recovery

### Common Issues

| Issue                  | Cause                          | Fix                                                             |
| ---------------------- | ------------------------------ | --------------------------------------------------------------- |
| `pgBossRunning: false` | PG Boss failed to start        | Check logs for initialization error, verify DATABASE_URL is set |
| Jobs not running       | Worker crashed/stopped         | Watchdog should auto-recover; if not, redeploy                  |
| Health returns 503     | PG Boss dead                   | Railway will auto-restart; check logs for root cause            |
| Rollover not happening | Check rollover_logs for errors | Fix error, delete failed log entry, redeploy                    |

---

## Desktop Auto-Update (Tauri v2 Updater)

**Ed25519 signing key:** `~/.tauri/opensunsama.key` (password: `opensunsama-updater-2026`)
**GitHub Secrets:** `TAURI_SIGNING_PRIVATE_KEY`, `TAURI_SIGNING_PRIVATE_KEY_PASSWORD`
**Update endpoint:** `GET /releases/update/:target/:current_version` (returns 204 or Tauri JSON). Tauri fills `{{target}}` with the OS alone (`darwin`, `linux`, `windows`), so the API answers those with Tauri's static format: one `platforms` entry per `{os}-{arch}`. Installed apps depend on this URL shape; don't change it.

### Critical CI/CD Notes

- **VITE_API_URL MUST be set on Tauri build steps** — Tauri's `beforeBuildCommand` rebuilds the web app. If `VITE_API_URL` is missing, the desktop app defaults to `localhost:3001` instead of `api.opensunsama.com`. Always pass `VITE_API_URL` and `VITE_WS_URL` as env vars on the Tauri build step itself.
- **Tauri HTTP plugin required** — WKWebView on macOS blocks cross-origin fetch from `tauri://` custom protocol. All API requests route through `@tauri-apps/plugin-http` (Rust-based) to bypass this. See `apps/web/src/lib/api.ts` `desktopFetch` wrapper.
- **Signing key password cannot be empty** — GitHub Actions doesn't support empty string secrets. Use a real password.
- **`strip = false` in Cargo.toml** — Required for `__TAURI_BUNDLE_TYPE` variable used by updater plugin.
- **Re-running a release is safe** — `POST /releases` upserts on version + platform, so re-running a failed job replaces its row.

---

## License

Non-Commercial License. Commercial use requires enterprise license.
