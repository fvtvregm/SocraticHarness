/**
 * Subtask routes for Open Sunsama API
 * Handles CRUD operations for subtasks within tasks
 */
import { Hono } from 'hono';
import { zValidator } from '@hono/zod-validator';
import { z } from 'zod';
import {
  getDb,
  eq,
  and,
  asc,
  inArray,
  subtasks,
  tasks,
  sql,
} from '@open-sunsama/database';
import { NotFoundError } from '@open-sunsama/utils';
import { auth, requireScopes, type AuthVariables } from '../middleware/auth.js';
import {
  createSubtaskSchema,
  updateSubtaskSchema,
  reorderSubtasksSchema,
  taskIdParamSchema,
  subtaskIdParamSchema,
} from '../validation/subtasks.js';
import { publishEvent } from '../lib/websocket/index.js';
import { stopTimerFields } from '../lib/timer.js';
import { startSubtaskTimer, stopSubtaskTimer, withTimerTransition } from '../lib/timer-service.js';

const subtasksRouter = new Hono<{ Variables: AuthVariables }>();
subtasksRouter.use('*', auth);

/**
 * Helper function to verify task ownership
 */
async function verifyTaskOwnership(db: Pick<ReturnType<typeof getDb>, "select">, taskId: string, userId: string) {
  const [task] = await db.select().from(tasks).where(and(eq(tasks.id, taskId), eq(tasks.userId, userId))).limit(1);
  if (!task) throw new NotFoundError('Task', taskId);
  return task;
}

/**
 * POST /tasks/subtasks-batch — Fetch subtasks for many tasks at once.
 *
 * The kanban shows N task cards visible at once and previously each card
 * fired its own GET /tasks/:id/subtasks. This endpoint returns subtasks
 * for every supplied taskId in one round-trip, grouped by taskId, so the
 * client can hydrate the entire view from a single request.
 *
 * Static path is intentionally registered before any `/:taskId/...` route
 * so Hono's matcher resolves the static segment first.
 */
const batchListSchema = z.object({
  taskIds: z.array(z.uuid()).max(500),
});
subtasksRouter.post(
  '/subtasks-batch',
  requireScopes('tasks:read'),
  zValidator('json', batchListSchema),
  async (c) => {
    const userId = c.get('userId');
    const { taskIds } = c.req.valid('json');
    const db = getDb();

    if (taskIds.length === 0) {
      return c.json({ success: true, data: {} as Record<string, unknown[]> });
    }

    // Only return subtasks for tasks the requester actually owns. We do
    // this with a single join rather than two queries so a malicious or
    // mistaken caller can't probe ownership by ID.
    const rows = await db
      .select({
        subtask: subtasks,
      })
      .from(subtasks)
      .innerJoin(tasks, eq(subtasks.taskId, tasks.id))
      .where(
        and(
          eq(tasks.userId, userId),
          inArray(subtasks.taskId, taskIds)
        )
      )
      .orderBy(asc(subtasks.position), asc(subtasks.createdAt));

    const grouped: Record<string, typeof rows[number]['subtask'][]> = {};
    for (const id of taskIds) {
      grouped[id] = [];
    }
    for (const row of rows) {
      const list = grouped[row.subtask.taskId];
      if (list) list.push(row.subtask);
    }

    return c.json({ success: true, data: grouped });
  }
);

/** GET /tasks/:taskId/subtasks - List subtasks for a task */
subtasksRouter.get(
  '/:taskId/subtasks',
  requireScopes('tasks:read'),
  zValidator('param', taskIdParamSchema),
  async (c) => {
    const userId = c.get('userId');
    const { taskId } = c.req.valid('param');
    const db = getDb();

    // Verify task ownership
    await verifyTaskOwnership(db, taskId, userId);

    const results = await db
      .select()
      .from(subtasks)
      .where(eq(subtasks.taskId, taskId))
      .orderBy(asc(subtasks.position), asc(subtasks.createdAt));

    return c.json({ success: true, data: results });
  }
);

/** POST /tasks/:taskId/subtasks - Create a subtask */
subtasksRouter.post(
  '/:taskId/subtasks',
  requireScopes('tasks:write'),
  zValidator('param', taskIdParamSchema),
  zValidator('json', createSubtaskSchema),
  async (c) => {
    const userId = c.get('userId');
    const { taskId } = c.req.valid('param');
    const data = c.req.valid('json');
    const db = getDb();

    // Verify task ownership
    await verifyTaskOwnership(db, taskId, userId);

    // Get max position if not provided
    let position = data.position;
    if (position === undefined) {
      const [maxPos] = await db
        .select({ max: sql<number>`COALESCE(MAX(${subtasks.position}), -1)` })
        .from(subtasks)
        .where(eq(subtasks.taskId, taskId));
      position = (maxPos?.max ?? -1) + 1;
    }

    const [newSubtask] = await db
      .insert(subtasks)
      .values({
        taskId,
        title: data.title,
        position,
      })
      .returning();

    // Publish realtime event (fire and forget) - subtask change affects parent task
    // Get parent task's scheduledDate for the event payload
    const [parentTask] = await db.select().from(tasks).where(eq(tasks.id, taskId)).limit(1);
    publishEvent(userId, 'task:updated', {
      taskId,
      scheduledDate: parentTask?.scheduledDate ?? null,
    });

    return c.json({ success: true, data: newSubtask }, 201);
  }
);

/** PATCH /tasks/:taskId/subtasks/:id - Update a subtask */
subtasksRouter.patch(
  '/:taskId/subtasks/:id',
  requireScopes('tasks:write'),
  zValidator('param', subtaskIdParamSchema),
  zValidator('json', updateSubtaskSchema),
  async (c) => {
    const userId = c.get('userId');
    const { taskId, id } = c.req.valid('param');
    const updates = c.req.valid('json');
    return withTimerTransition(getDb(), userId, async (db, publishEvent) => {

      // Verify task ownership
      await verifyTaskOwnership(db, taskId, userId);

      // Verify subtask exists and belongs to task
      const [existing] = await db
        .select()
        .from(subtasks)
        .where(and(eq(subtasks.id, id), eq(subtasks.taskId, taskId)))
        .limit(1);
      if (!existing) throw new NotFoundError('Subtask', id);

      const updateData: Record<string, unknown> = { updatedAt: new Date() };
      if (updates.title !== undefined) updateData.title = updates.title;
      if (updates.completed !== undefined) updateData.completed = updates.completed;
      if (updates.position !== undefined) updateData.position = updates.position;
      if (updates.estimatedMins !== undefined) updateData.estimatedMins = updates.estimatedMins;
      if (updates.actualMins !== undefined) {
        // A typed actual time replaces what the timer logged; a running timer
        // carries on from it.
        updateData.actualMins = updates.actualMins;
        updateData.timerAccumulatedSeconds = (updates.actualMins ?? 0) * 60;
        if (existing.timerStartedAt) updateData.timerStartedAt = new Date();
      }
      // Ticking off a subtask stops its timer; the task's keeps running so
      // the next subtask can pick up where this one ended.
      if (updates.completed && existing.timerStartedAt) {
        if (updates.actualMins === undefined) Object.assign(updateData, stopTimerFields(existing));
        else updateData.timerStartedAt = null;
      }

      const [updatedSubtask] = await db
        .update(subtasks)
        .set(updateData)
        .where(and(eq(subtasks.id, id), eq(subtasks.taskId, taskId)))
        .returning();

      // Publish realtime event (fire and forget) - subtask change affects parent task
      // Get parent task's scheduledDate for the event payload
      const [parentTask] = await db.select().from(tasks).where(eq(tasks.id, taskId)).limit(1);
      publishEvent(userId, 'task:updated', {
        taskId,
        scheduledDate: parentTask?.scheduledDate ?? null,
      });

      return c.json({ success: true, data: updatedSubtask });
    });
  }
);

/** Loads a task and one of its subtasks, both owned by the user. */
async function loadSubtask(
  db: ReturnType<typeof getDb>,
  userId: string,
  taskId: string,
  id: string
) {
  const task = await verifyTaskOwnership(db, taskId, userId);
  const [subtask] = await db
    .select()
    .from(subtasks)
    .where(and(eq(subtasks.id, id), eq(subtasks.taskId, taskId)))
    .limit(1);
  if (!subtask) throw new NotFoundError('Subtask', id);
  return { task, subtask };
}

/**
 * POST /tasks/:taskId/subtasks/:id/timer/start - Time one subtask. The
 * task's timer starts too (and any other timer stops), so the task's actual
 * time includes the subtask's.
 */
subtasksRouter.post(
  '/:taskId/subtasks/:id/timer/start',
  requireScopes('tasks:write'),
  zValidator('param', subtaskIdParamSchema),
  async (c) => {
    const userId = c.get('userId');
    const { taskId, id } = c.req.valid('param');
    const db = getDb();
    const { task, subtask } = await loadSubtask(db, userId, taskId, id);
    const result = await startSubtaskTimer(db, userId, task, subtask);
    return c.json({
      success: true,
      data: result.subtask,
      task: result.task,
      stoppedTask: result.stoppedTask,
    });
  }
);

/** POST /tasks/:taskId/subtasks/:id/timer/stop - Stop a subtask and its task. */
subtasksRouter.post(
  '/:taskId/subtasks/:id/timer/stop',
  requireScopes('tasks:write'),
  zValidator('param', subtaskIdParamSchema),
  async (c) => {
    const userId = c.get('userId');
    const { taskId, id } = c.req.valid('param');
    const db = getDb();
    const { task, subtask } = await loadSubtask(db, userId, taskId, id);
    const result = await stopSubtaskTimer(db, userId, task, subtask);
    return c.json({ success: true, data: result.subtask, task: result.task });
  }
);

/** DELETE /tasks/:taskId/subtasks/:id - Delete a subtask */
subtasksRouter.delete(
  '/:taskId/subtasks/:id',
  requireScopes('tasks:write'),
  zValidator('param', subtaskIdParamSchema),
  async (c) => {
    const userId = c.get('userId');
    const { taskId, id } = c.req.valid('param');
    const db = getDb();

    // Verify task ownership
    await verifyTaskOwnership(db, taskId, userId);

    // Verify subtask exists and belongs to task
    const [existing] = await db
      .select()
      .from(subtasks)
      .where(and(eq(subtasks.id, id), eq(subtasks.taskId, taskId)))
      .limit(1);
    if (!existing) throw new NotFoundError('Subtask', id);

    await db.delete(subtasks).where(and(eq(subtasks.id, id), eq(subtasks.taskId, taskId)));

    // Publish realtime event (fire and forget) - subtask change affects parent task
    // Get parent task's scheduledDate for the event payload
    const [parentTask] = await db.select().from(tasks).where(eq(tasks.id, taskId)).limit(1);
    publishEvent(userId, 'task:updated', {
      taskId,
      scheduledDate: parentTask?.scheduledDate ?? null,
    });

    return c.json({ success: true, message: 'Subtask deleted successfully' });
  }
);

/** POST /tasks/:taskId/subtasks/reorder - Reorder subtasks */
subtasksRouter.post(
  '/:taskId/subtasks/reorder',
  requireScopes('tasks:write'),
  zValidator('param', taskIdParamSchema),
  zValidator('json', reorderSubtasksSchema),
  async (c) => {
    const userId = c.get('userId');
    const { taskId } = c.req.valid('param');
    const { subtaskIds } = c.req.valid('json');
    const db = getDb();

    // Verify task ownership
    await verifyTaskOwnership(db, taskId, userId);

    // Update positions for each subtask
    await Promise.all(
      subtaskIds.map((subtaskId, index) =>
        db
          .update(subtasks)
          .set({ position: index, updatedAt: new Date() })
          .where(and(eq(subtasks.id, subtaskId), eq(subtasks.taskId, taskId)))
      )
    );

    // Fetch updated subtasks
    const updatedSubtasks = await db
      .select()
      .from(subtasks)
      .where(eq(subtasks.taskId, taskId))
      .orderBy(asc(subtasks.position));

    return c.json({ success: true, data: updatedSubtasks, message: 'Subtasks reordered successfully' });
  }
);

export { subtasksRouter };
