/**
 * Calendar events routes for Open Sunsama API
 * Fetch events for display, plus write-back (edit / delete) for providers
 * that support it.
 */
import { Hono } from 'hono';
import { zValidator } from '@hono/zod-validator';
import { z } from 'zod';
import {
  getDb,
  eq,
  and,
  gte,
  lte,
  inArray,
  calendars,
  calendarAccounts,
  calendarEvents,
  users,
} from '@open-sunsama/database';
import {
  auth,
  requireScopes,
  requireAnyScope,
  type AuthVariables,
} from '../middleware/auth.js';
import {
  localDayWindow,
  eventFallsInWindow,
  type LocalDayWindow,
} from '../lib/calendar-day-window.js';
import {
  calendarEventsQuerySchema,
  parseCalendarIds,
} from '../validation/calendar.js';
import {
  getProvider,
  getAccessTokenForProvider,
} from '../services/calendar-sync.js';
import {
  ProviderReadOnlyError,
  ProviderEventNotFoundError,
  ProviderAuthError,
  type EventPatch,
  type CalendarProvider,
} from '../services/calendar-providers/index.js';
import { publishEvent } from '../lib/websocket/index.js';

const calendarEventsRouter = new Hono<{ Variables: AuthVariables }>();
calendarEventsRouter.use('*', auth);

const DAY_MS = 24 * 60 * 60 * 1000;
const DATE_ONLY = /^\d{4}-\d{2}-\d{2}$/;

/**
 * GET /calendar-events
 * List calendar events from enabled calendars.
 *
 * - `from`/`to` as ISO instants: events overlapping that span (the web app).
 * - `date`, or `from`/`to` as YYYY-MM-DD: events on those whole days in the
 *   user's timezone, `to` inclusive (MCP tools, API keys).
 *
 * `calendar:read` is the scope for this; `user:read` still works because
 * API keys used it before `calendar:read` existed.
 */
calendarEventsRouter.get(
  '/',
  requireAnyScope('calendar:read', 'user:read'),
  zValidator('query', calendarEventsQuerySchema),
  async (c) => {
    const userId = c.get('userId');
    const query = c.req.valid('query');
    const calendarIdsParam = query.calendarIds;
    const db = getDb();

    const [user] = await db
      .select({ timezone: users.timezone })
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);
    const userTimezone = user?.timezone || 'UTC';

    // Local-day mode when the caller speaks in dates, not instants.
    const dayWindow: LocalDayWindow | null = query.date
      ? localDayWindow(query.date, query.date, userTimezone)
      : DATE_ONLY.test(query.from!) && DATE_ONLY.test(query.to!)
        ? localDayWindow(query.from!, query.to!, userTimezone)
        : null;

    // SQL range; in day mode widened a day each side so all-day events,
    // stored at UTC midnight, are fetched and then matched by date below.
    const fromDate = dayWindow
      ? new Date(dayWindow.start.getTime() - DAY_MS)
      : new Date(query.from!);
    const toDate = dayWindow
      ? new Date(dayWindow.end.getTime() + DAY_MS)
      : new Date(query.to!);

    // Parse optional calendar IDs filter
    const calendarIds = parseCalendarIds(calendarIdsParam);

    // First, get enabled calendars for user
    const enabledCalendarQuery = db
      .select({ id: calendars.id })
      .from(calendars)
      .where(
        and(
          eq(calendars.userId, userId),
          eq(calendars.isEnabled, true)
        )
      );

    // If specific calendar IDs are provided, filter to those
    const enabledCalendars = await enabledCalendarQuery;
    let calendarIdFilter = enabledCalendars.map((c) => c.id);

    // If calendarIds filter is provided, intersect with enabled calendars
    if (calendarIds && calendarIds.length > 0) {
      calendarIdFilter = calendarIdFilter.filter((id) =>
        calendarIds.includes(id)
      );
    }

    // If no calendars to query, return empty result
    if (calendarIdFilter.length === 0) {
      return c.json({
        success: true,
        data: [],
        meta: { total: 0, timezone: dayWindow?.timezone ?? userTimezone },
      });
    }

    // Fetch events from enabled calendars within date range
    const events = await db
      .select({
        id: calendarEvents.id,
        calendarId: calendarEvents.calendarId,
        externalId: calendarEvents.externalId,
        title: calendarEvents.title,
        description: calendarEvents.description,
        location: calendarEvents.location,
        startTime: calendarEvents.startTime,
        endTime: calendarEvents.endTime,
        isAllDay: calendarEvents.isAllDay,
        timezone: calendarEvents.timezone,
        recurrenceRule: calendarEvents.recurrenceRule,
        recurringEventId: calendarEvents.recurringEventId,
        status: calendarEvents.status,
        responseStatus: calendarEvents.responseStatus,
        htmlLink: calendarEvents.htmlLink,
        attendees: calendarEvents.attendees,
        conferenceUrl: calendarEvents.conferenceUrl,
        createdAt: calendarEvents.createdAt,
        updatedAt: calendarEvents.updatedAt,
      })
      .from(calendarEvents)
      .where(
        and(
          eq(calendarEvents.userId, userId),
          inArray(calendarEvents.calendarId, calendarIdFilter),
          // Events that overlap with the date range:
          // Event starts before range ends AND event ends after range starts
          lte(calendarEvents.startTime, toDate),
          gte(calendarEvents.endTime, fromDate)
        )
      )
      .orderBy(calendarEvents.startTime);

    // Fetch calendar info to enrich events
    const calendarsInfo = await db
      .select({
        id: calendars.id,
        name: calendars.name,
        color: calendars.color,
        accountId: calendars.accountId,
      })
      .from(calendars)
      .where(inArray(calendars.id, calendarIdFilter));

    const calendarsMap = new Map(
      calendarsInfo.map((cal) => [cal.id, cal])
    );

    const inRange = dayWindow
      ? events.filter((event) => eventFallsInWindow(event, dayWindow))
      : events;

    // Enrich events with calendar info
    const enrichedEvents = inRange.map((event) => {
      const calendar = calendarsMap.get(event.calendarId);
      return {
        ...event,
        calendar: calendar
          ? {
              id: calendar.id,
              name: calendar.name,
              color: calendar.color,
            }
          : null,
      };
    });

    return c.json({
      success: true,
      data: enrichedEvents,
      meta: {
        from: (dayWindow?.start ?? fromDate).toISOString(),
        to: (dayWindow?.end ?? toDate).toISOString(),
        total: enrichedEvents.length,
        timezone: dayWindow?.timezone ?? userTimezone,
        ...(dayWindow ? { fromDate: dayWindow.fromDate, toDate: dayWindow.toDate } : {}),
      },
    });
  }
);

/**
 * Resolve the per-provider access token, mapping `ProviderAuthError`
 * to a clean 401 JSON response object. The route checks the return
 * value: a string means success; an object with `success: false`
 * means auth failed and the route should return that response
 * verbatim. Pulled into a helper because all three write routes
 * (POST / PATCH / DELETE) share this guard.
 */
async function resolveAccessTokenOrAuthFail(
  account: Parameters<typeof getAccessTokenForProvider>[0],
  provider: CalendarProvider
): Promise<
  | { ok: true; accessToken: string }
  | { ok: false; status: 401; body: { success: false; error: { code: string; message: string } } }
> {
  try {
    const accessToken = await getAccessTokenForProvider(account, provider);
    return { ok: true, accessToken };
  } catch (err) {
    if (err instanceof ProviderAuthError) {
      return {
        ok: false,
        status: 401,
        body: {
          success: false,
          error: {
            code: 'PROVIDER_AUTH_FAILED',
            message:
              'Your calendar connection needs to be re-authorized. Reconnect the account in Settings.',
          },
        },
      };
    }
    throw err;
  }
}

/**
 * Common helper: load the event together with its calendar + account so
 * we can write back via the right provider with a fresh token. Returns
 * 404 with a `null` payload if the event doesn't belong to this user.
 */
async function loadEventForWrite(eventId: string, userId: string) {
  const db = getDb();
  const rows = await db
    .select({
      event: calendarEvents,
      calendar: calendars,
      account: calendarAccounts,
    })
    .from(calendarEvents)
    .innerJoin(calendars, eq(calendars.id, calendarEvents.calendarId))
    .innerJoin(
      calendarAccounts,
      eq(calendarAccounts.id, calendars.accountId)
    )
    .where(
      and(
        eq(calendarEvents.id, eventId),
        eq(calendarEvents.userId, userId)
      )
    )
    .limit(1);

  return rows[0] ?? null;
}

/**
 * Body for POST /calendar-events. The client picks which writable
 * calendar to host the new event on. Times are ISO 8601.
 */
const createEventBodySchema = z
  .object({
    calendarId: z.uuid(),
    title: z.string().min(1).max(500),
    description: z.string().max(50_000).nullable().optional(),
    location: z.string().max(1000).nullable().optional(),
    startTime: z.iso.datetime(),
    endTime: z.iso.datetime(),
    isAllDay: z.boolean().optional(),
    timezone: z.string().max(100).nullable().optional(),
  })
  .refine((b) => new Date(b.endTime) > new Date(b.startTime), {
    error: 'endTime must be after startTime',
    path: ['endTime'],
  });

/**
 * POST /calendar-events
 * Create a new external calendar event. Sends to the provider first;
 * only writes locally on success so we don't end up with orphan rows.
 * Returns the created event with calendar metadata enriched.
 */
calendarEventsRouter.post(
  '/',
  requireScopes('user:write'),
  zValidator('json', createEventBodySchema),
  async (c) => {
    const userId = c.get('userId');
    const body = c.req.valid('json');
    const db = getDb();

    // Resolve calendar + account; verify ownership and write capability.
    const [target] = await db
      .select({
        calendar: calendars,
        account: calendarAccounts,
      })
      .from(calendars)
      .innerJoin(
        calendarAccounts,
        eq(calendarAccounts.id, calendars.accountId)
      )
      .where(
        and(
          eq(calendars.id, body.calendarId),
          eq(calendars.userId, userId)
        )
      )
      .limit(1);

    if (!target) {
      return c.json(
        { success: false, error: { code: 'NOT_FOUND', message: 'Calendar not found' } },
        404
      );
    }

    if (target.calendar.isReadOnly) {
      return c.json(
        {
          success: false,
          error: {
            code: 'CALENDAR_READ_ONLY',
            message: 'This calendar is read-only — events cannot be created here.',
          },
        },
        409
      );
    }

    const provider = getProvider(target.account.provider);
    if (!provider || !provider.createEvent) {
      return c.json(
        {
          success: false,
          error: {
            code: 'PROVIDER_READ_ONLY',
            message: `Creating ${target.account.provider} events is not yet supported.`,
          },
        },
        409
      );
    }

    const tokenResult = await resolveAccessTokenOrAuthFail(
      target.account,
      provider
    );
    if (!tokenResult.ok) return c.json(tokenResult.body, tokenResult.status);
    const accessToken = tokenResult.accessToken;

    const payload: EventPatch = {
      title: body.title,
      description: body.description ?? undefined,
      location: body.location ?? undefined,
      startTime: new Date(body.startTime),
      endTime: new Date(body.endTime),
      isAllDay: body.isAllDay ?? false,
      timezone: body.timezone ?? undefined,
    };

    let externalEvent;
    try {
      externalEvent = await provider.createEvent(
        accessToken,
        target.calendar.externalId,
        payload
      );
    } catch (err) {
      if (err instanceof ProviderReadOnlyError) {
        return c.json(
          {
            success: false,
            error: { code: 'PROVIDER_READ_ONLY', message: err.message },
          },
          409
        );
      }
      if (err instanceof ProviderEventNotFoundError) {
        return c.json(
          {
            success: false,
            error: {
              code: 'CALENDAR_OUT_OF_SYNC',
              message:
                'This calendar is out of sync. Run "Reset & re-sync" in Settings.',
            },
          },
          410
        );
      }
      if (err instanceof ProviderAuthError) {
        return c.json(
          {
            success: false,
            error: {
              code: 'PROVIDER_AUTH_FAILED',
              message:
                'Your calendar connection needs to be re-authorized. Reconnect the account in Settings.',
            },
          },
          401
        );
      }
      const message = err instanceof Error ? err.message : 'Unknown error';
      return c.json(
        {
          success: false,
          error: { code: 'PROVIDER_ERROR', message },
        },
        502
      );
    }

    const [created] = await db
      .insert(calendarEvents)
      .values({
        calendarId: body.calendarId,
        userId,
        externalId: externalEvent.externalId,
        title: externalEvent.title,
        description: externalEvent.description,
        location: externalEvent.location,
        startTime: externalEvent.startTime,
        endTime: externalEvent.endTime,
        isAllDay: externalEvent.isAllDay,
        timezone: externalEvent.timezone,
        recurrenceRule: externalEvent.recurrenceRule,
        recurringEventId: externalEvent.recurringEventId,
        status: externalEvent.status,
        responseStatus: externalEvent.responseStatus,
        htmlLink: externalEvent.htmlLink,
        etag: externalEvent.etag,
        attendees: externalEvent.attendees,
        conferenceUrl: externalEvent.conferenceUrl,
      })
      .returning();

    if (created) {
      await publishEvent(userId, 'calendar-event:updated', {
        id: created.id,
        calendarId: created.calendarId,
      });
    }

    return c.json(
      {
        success: true,
        data: {
          ...created,
          calendar: {
            id: target.calendar.id,
            name: target.calendar.name,
            color: target.calendar.color,
          },
        },
      },
      201
    );
  }
);

/**
 * Body for PATCH /calendar-events/:id. All fields optional. The client
 * may send any subset of the editable fields. Times are ISO 8601.
 */
const updateEventBodySchema = z
  .object({
    title: z.string().min(1).max(500).optional(),
    description: z.string().max(50_000).nullable().optional(),
    location: z.string().max(1000).nullable().optional(),
    startTime: z.iso.datetime().optional(),
    endTime: z.iso.datetime().optional(),
    isAllDay: z.boolean().optional(),
    timezone: z.string().max(100).nullable().optional(),
  })
  .refine(
    (b) =>
      (b.startTime === undefined && b.endTime === undefined) ||
      (b.startTime !== undefined && b.endTime !== undefined),
    {
      error: 'startTime and endTime must be provided together',
      path: ['endTime'],
    }
  )
  .refine(
    (b) =>
      b.startTime === undefined ||
      b.endTime === undefined ||
      new Date(b.endTime) > new Date(b.startTime),
    {
      error: 'endTime must be after startTime',
      path: ['endTime'],
    }
  );

/**
 * PATCH /calendar-events/:id
 * Edit an external calendar event. The change is sent upstream to the
 * provider and only persisted locally if the upstream write succeeds —
 * we don't want a divergent local state if the user lacks permission
 * or the provider is down. Returns the updated event payload.
 */
calendarEventsRouter.patch(
  '/:id',
  requireScopes('user:write'),
  zValidator('json', updateEventBodySchema),
  async (c) => {
    const userId = c.get('userId');
    const eventId = c.req.param('id');
    const body = c.req.valid('json');
    const db = getDb();

    const row = await loadEventForWrite(eventId, userId);
    if (!row) {
      return c.json(
        { success: false, error: { code: 'NOT_FOUND', message: 'Event not found' } },
        404
      );
    }

    if (row.calendar.isReadOnly) {
      return c.json(
        {
          success: false,
          error: {
            code: 'CALENDAR_READ_ONLY',
            message: 'This calendar is read-only — events cannot be edited.',
          },
        },
        409
      );
    }

    const provider = getProvider(row.account.provider);
    if (!provider || !provider.updateEvent) {
      return c.json(
        {
          success: false,
          error: {
            code: 'PROVIDER_READ_ONLY',
            message: `Editing ${row.account.provider} events is not yet supported.`,
          },
        },
        409
      );
    }

    const tokenResult = await resolveAccessTokenOrAuthFail(
      row.account,
      provider
    );
    if (!tokenResult.ok) return c.json(tokenResult.body, tokenResult.status);
    const accessToken = tokenResult.accessToken;

    const patch: EventPatch = {};
    if (body.title !== undefined) patch.title = body.title;
    if (body.description !== undefined) patch.description = body.description;
    if (body.location !== undefined) patch.location = body.location;
    if (body.startTime !== undefined && body.endTime !== undefined) {
      patch.startTime = new Date(body.startTime);
      patch.endTime = new Date(body.endTime);
    }
    if (body.isAllDay !== undefined) patch.isAllDay = body.isAllDay;
    if (body.timezone !== undefined) patch.timezone = body.timezone;
    // CalDAV (iCloud) addresses events by URL, not just by UID. The
    // local row stores the URL in `htmlLink` — pass it through so
    // the iCloud provider can target the right .ics object.
    // Google / Outlook ignore this field.
    if (row.event.htmlLink) patch.eventUrl = row.event.htmlLink;

    let updatedExternal;
    try {
      updatedExternal = await provider.updateEvent(
        accessToken,
        row.calendar.externalId,
        row.event.externalId,
        patch
      );
    } catch (err) {
      if (err instanceof ProviderReadOnlyError) {
        return c.json(
          {
            success: false,
            error: { code: 'PROVIDER_READ_ONLY', message: err.message },
          },
          409
        );
      }
      if (err instanceof ProviderEventNotFoundError) {
        // The event no longer exists upstream — most likely deleted in
        // the provider's UI, or a residue of pre-PR-#21 attribution
        // corruption pointing our local row at a calendar/event id
        // pair that doesn't match Google. Either way, the local row
        // is stale; remove it so the next refetch hides it instead of
        // surfacing the same broken event again. Return 410 with a
        // clean, actionable message.
        await db
          .delete(calendarEvents)
          .where(eq(calendarEvents.id, eventId));
        return c.json(
          {
            success: false,
            error: {
              code: 'EVENT_OUT_OF_SYNC',
              message:
                'This event is out of sync with your calendar. Refresh or run "Reset & re-sync" in Settings.',
            },
          },
          410
        );
      }
      if (err instanceof ProviderAuthError) {
        return c.json(
          {
            success: false,
            error: {
              code: 'PROVIDER_AUTH_FAILED',
              message:
                'Your calendar connection needs to be re-authorized. Reconnect the account in Settings.',
            },
          },
          401
        );
      }
      const message = err instanceof Error ? err.message : 'Unknown error';
      return c.json(
        {
          success: false,
          error: { code: 'PROVIDER_ERROR', message },
        },
        502
      );
    }

    // Write-through to local DB so the user sees the change immediately
    // without waiting for the next sync. The provider response is the
    // canonical post-write state.
    const [updated] = await db
      .update(calendarEvents)
      .set({
        title: updatedExternal.title,
        description: updatedExternal.description,
        location: updatedExternal.location,
        startTime: updatedExternal.startTime,
        endTime: updatedExternal.endTime,
        isAllDay: updatedExternal.isAllDay,
        timezone: updatedExternal.timezone,
        status: updatedExternal.status,
        responseStatus: updatedExternal.responseStatus,
        htmlLink: updatedExternal.htmlLink,
        etag: updatedExternal.etag,
        attendees: updatedExternal.attendees,
        conferenceUrl: updatedExternal.conferenceUrl,
        updatedAt: new Date(),
      })
      .where(eq(calendarEvents.id, eventId))
      .returning();

    if (updated) {
      // Notify other tabs / devices via the realtime channel; the client
      // invalidates the calendar-events query on receipt.
      await publishEvent(userId, 'calendar-event:updated', {
        id: updated.id,
        calendarId: updated.calendarId,
      });
    }

    return c.json({
      success: true,
      data: {
        ...updated,
        calendar: {
          id: row.calendar.id,
          name: row.calendar.name,
          color: row.calendar.color,
        },
      },
    });
  }
);

const rsvpBodySchema = z.object({
  response: z.enum(['accepted', 'declined', 'tentative']),
});

/**
 * POST /calendar-events/:id/rsvp
 * Answer an invitation (going, maybe, not going) as the connected
 * account. The provider notifies the organizer, as its own app would.
 */
calendarEventsRouter.post(
  '/:id/rsvp',
  requireScopes('user:write'),
  zValidator('json', rsvpBodySchema),
  async (c) => {
    const userId = c.get('userId');
    const eventId = c.req.param('id');
    const { response } = c.req.valid('json');
    const db = getDb();

    const row = await loadEventForWrite(eventId, userId);
    if (!row) {
      return c.json(
        { success: false, error: { code: 'NOT_FOUND', message: 'Event not found' } },
        404
      );
    }

    const provider = getProvider(row.account.provider);
    if (!provider || !provider.respondToEvent) {
      return c.json(
        {
          success: false,
          error: {
            code: 'PROVIDER_READ_ONLY',
            message: `Answering ${row.account.provider} invitations is not supported yet.`,
          },
        },
        409
      );
    }

    const tokenResult = await resolveAccessTokenOrAuthFail(
      row.account,
      provider
    );
    if (!tokenResult.ok) return c.json(tokenResult.body, tokenResult.status);

    let answered;
    try {
      answered = await provider.respondToEvent(
        tokenResult.accessToken,
        row.calendar.externalId,
        row.event.externalId,
        response
      );
    } catch (err) {
      if (err instanceof ProviderReadOnlyError) {
        return c.json(
          {
            success: false,
            error: {
              code: 'NOT_INVITED',
              message: 'Only guests can answer an invitation.',
            },
          },
          409
        );
      }
      if (err instanceof ProviderEventNotFoundError) {
        return c.json(
          {
            success: false,
            error: {
              code: 'EVENT_OUT_OF_SYNC',
              message:
                'This event is out of sync with your calendar. Refresh or run "Reset & re-sync" in Settings.',
            },
          },
          410
        );
      }
      if (err instanceof ProviderAuthError) {
        return c.json(
          {
            success: false,
            error: {
              code: 'PROVIDER_AUTH_FAILED',
              message:
                'Your calendar connection needs to be re-authorized. Reconnect the account in Settings.',
            },
          },
          401
        );
      }
      const message = err instanceof Error ? err.message : 'Unknown error';
      return c.json(
        { success: false, error: { code: 'PROVIDER_ERROR', message } },
        502
      );
    }

    // Outlook doesn't mark our own attendee entry, so the answer we just
    // sent is the authoritative response status.
    const [updated] = await db
      .update(calendarEvents)
      .set({
        responseStatus: response,
        attendees: answered.attendees,
        etag: answered.etag,
        updatedAt: new Date(),
      })
      .where(eq(calendarEvents.id, eventId))
      .returning();

    if (updated) {
      await publishEvent(userId, 'calendar-event:updated', {
        id: updated.id,
        calendarId: updated.calendarId,
      });
    }

    return c.json({
      success: true,
      data: {
        ...updated,
        calendar: {
          id: row.calendar.id,
          name: row.calendar.name,
          color: row.calendar.color,
        },
      },
    });
  }
);

/**
 * DELETE /calendar-events/:id
 * Delete an external calendar event upstream and locally.
 */
calendarEventsRouter.delete(
  '/:id',
  requireScopes('user:write'),
  async (c) => {
    const userId = c.get('userId');
    const eventId = c.req.param('id');
    const db = getDb();

    const row = await loadEventForWrite(eventId, userId);
    if (!row) {
      return c.json(
        { success: false, error: { code: 'NOT_FOUND', message: 'Event not found' } },
        404
      );
    }

    if (row.calendar.isReadOnly) {
      return c.json(
        {
          success: false,
          error: {
            code: 'CALENDAR_READ_ONLY',
            message: 'This calendar is read-only — events cannot be deleted.',
          },
        },
        409
      );
    }

    const provider = getProvider(row.account.provider);
    if (!provider || !provider.deleteEvent) {
      return c.json(
        {
          success: false,
          error: {
            code: 'PROVIDER_READ_ONLY',
            message: `Deleting ${row.account.provider} events is not yet supported.`,
          },
        },
        409
      );
    }

    const tokenResult = await resolveAccessTokenOrAuthFail(
      row.account,
      provider
    );
    if (!tokenResult.ok) return c.json(tokenResult.body, tokenResult.status);
    const accessToken = tokenResult.accessToken;

    try {
      await provider.deleteEvent(
        accessToken,
        row.calendar.externalId,
        row.event.externalId,
        // iCloud needs the resource URL + etag to delete; Google /
        // Outlook ignore the extras.
        { eventUrl: row.event.htmlLink, etag: row.event.etag }
      );
    } catch (err) {
      if (err instanceof ProviderReadOnlyError) {
        return c.json(
          {
            success: false,
            error: { code: 'PROVIDER_READ_ONLY', message: err.message },
          },
          409
        );
      }
      if (err instanceof ProviderEventNotFoundError) {
        // Same out-of-sync semantics as PATCH: the upstream says
        // the event doesn't exist (or our local row is stale, e.g.
        // pre-PR iCloud row with null htmlLink). Treat as success
        // from the user's POV — the event is gone either way.
        // Clean up the local row + publish so other tabs refetch.
        await db.delete(calendarEvents).where(eq(calendarEvents.id, eventId));
        await publishEvent(userId, 'calendar-event:deleted', {
          id: eventId,
          calendarId: row.calendar.id,
        });
        return c.json(
          {
            success: false,
            error: {
              code: 'EVENT_OUT_OF_SYNC',
              message:
                'This event is out of sync with your calendar. Refresh or run "Reset & re-sync" in Settings.',
            },
          },
          410
        );
      }
      if (err instanceof ProviderAuthError) {
        return c.json(
          {
            success: false,
            error: {
              code: 'PROVIDER_AUTH_FAILED',
              message:
                'Your calendar connection needs to be re-authorized. Reconnect the account in Settings.',
            },
          },
          401
        );
      }
      const message = err instanceof Error ? err.message : 'Unknown error';
      return c.json(
        {
          success: false,
          error: { code: 'PROVIDER_ERROR', message },
        },
        502
      );
    }

    await db.delete(calendarEvents).where(eq(calendarEvents.id, eventId));

    await publishEvent(userId, 'calendar-event:deleted', {
      id: eventId,
      calendarId: row.calendar.id,
    });

    return c.json({ success: true });
  }
);

export { calendarEventsRouter };
