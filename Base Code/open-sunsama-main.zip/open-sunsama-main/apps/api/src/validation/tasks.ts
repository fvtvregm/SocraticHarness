/**
 * Validation schemas for tasks routes
 */

import { z } from 'zod';
import { uuidSchema, dateSchema } from '@open-sunsama/utils';

/**
 * Priority levels for tasks
 */
export const prioritySchema = z.enum(['P0', 'P1', 'P2', 'P3']);

/**
 * Sort by options for tasks
 */
export const sortBySchema = z.enum(['priority', 'position', 'createdAt']);

/**
 * Schema for creating a task
 */
export const createTaskSchema = z.object({
  title: z.string({ error: (issue) => issue.input === undefined ? 'Title is required' : undefined })
    .min(1, { error: 'Title is required' }).max(500),
  notes: z.string().max(5000).optional().nullable(),
  scheduledDate: dateSchema.optional().nullable(),
  estimatedMins: z.number().int().positive().max(1440).optional().nullable(),
  priority: prioritySchema.optional(),
  position: z.number().int().nonnegative().optional(),
});

/**
 * Schema for updating a task
 */
export const updateTaskSchema = z.object({
  title: z.string().min(1).max(500).optional(),
  notes: z.string().max(5000).optional().nullable(),
  scheduledDate: dateSchema.optional().nullable(),
  estimatedMins: z.number().int().positive().max(1440).optional().nullable(),
  actualMins: z.number().int().nonnegative().optional().nullable(),
  priority: prioritySchema.optional(),
  completedAt: z.iso.datetime().optional().nullable(),
  position: z.number().int().nonnegative().optional(),
  subtasksHidden: z.boolean().optional(),
});

/**
 * Schema for filtering tasks
 */
export const taskFilterSchema = z.object({
  /**
   * Case-insensitive substring match on the title or notes. Needed by the
   * command palette: it used to pull the first page of tasks and filter in the
   * browser, so anything past that page was invisible to search.
   */
  search: z.string().trim().min(1).max(200).optional(),
  date: dateSchema.optional(),
  from: dateSchema.optional(),
  to: dateSchema.optional(),
  completed: z.enum(['true', 'false']).optional(),
  backlog: z.enum(['true', 'false']).optional(),
  priority: prioritySchema.optional(),
  sortBy: sortBySchema.optional(),
  page: z.coerce.number().int().min(1).default(1),
  // Must stay >= RANGE_FETCH_LIMIT in apps/web/src/hooks/useKanbanRangePrefetch.ts,
  // which asks for a whole visible month in one call. When this cap was
  // lower than that constant the board's range prefetch 400'd outright.
  limit: z.coerce.number().int().min(1).max(1000).default(50),
  // Inline-include the subtasks for each task. Used by the kanban range
  // prefetch so we don't have to fire a follow-up `subtasks-batch` request
  // for tasks the client already has in hand.
  includeSubtasks: z.enum(['true', 'false']).optional(),
});

/**
 * Schema for reordering tasks
 */
export const reorderTasksSchema = z.object({
  date: z.union([dateSchema, z.literal('backlog')]),
  taskIds: z.array(uuidSchema).min(1),
});
