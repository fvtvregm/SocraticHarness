/**
 * Validation schemas for calendar routes
 */

import { z } from 'zod';
import { uuidSchema, dateSchema } from '@open-sunsama/utils';

/**
 * Calendar provider enum
 */
export const calendarProviderSchema = z.enum(['google', 'outlook', 'icloud']);

/**
 * Schema for OAuth initiate route params
 */
export const oauthInitiateParamsSchema = z.object({
  provider: z.enum(['google', 'outlook']),
});

/**
 * Schema for OAuth callback query params
 */
export const oauthCallbackQuerySchema = z.object({
  code: z.string().min(1, { error: 'Authorization code is required' }),
  state: z.string().min(1, { error: 'State parameter is required' }),
  error: z.string().optional(),
  error_description: z.string().optional(),
});

/**
 * Schema for CalDAV connect body
 */
export const caldavConnectSchema = z.object({
  email: z.email({ error: 'Invalid email address' }).max(255),
  appPassword: z.string().min(1, { error: 'App password is required' }).max(255),
  caldavUrl: z.url().max(500).optional(),
});

/**
 * Schema for calendar account ID param
 */
export const calendarAccountIdParamSchema = z.object({
  id: uuidSchema,
});

/**
 * Schema for calendar ID param
 */
export const calendarIdParamSchema = z.object({
  id: uuidSchema,
});

/**
 * Schema for updating calendar settings.
 *
 * `color` is the user's override — when set, it takes precedence over
 * the color the provider returned at sync time. Pass null to clear
 * the override and fall back to the provider color.
 */
export const updateCalendarSettingsSchema = z.object({
  isEnabled: z.boolean().optional(),
  isDefaultForEvents: z.boolean().optional(),
  isDefaultForTasks: z.boolean().optional(),
  color: z
    .string()
    .regex(/^#[0-9A-Fa-f]{6}$/, { error: 'color must be a #RRGGBB hex string' })
    .nullable()
    .optional(),
});

/**
 * Schema for calendar events query params
 */
export const calendarEventsQuerySchema = z
  .object({
    // ISO instants, or YYYY-MM-DD for whole days in the user's timezone.
    from: z.iso.datetime({ offset: true }).or(dateSchema).optional(),
    to: z.iso.datetime({ offset: true }).or(dateSchema).optional(),
    // Shorthand for from=to=date.
    date: dateSchema.optional(),
    calendarIds: z.string().optional(), // Comma-separated UUIDs
  })
  .refine((q) => (q.date ? !q.from && !q.to : !!q.from && !!q.to), {
    error: 'Pass either date, or both from and to',
  });

/**
 * Parse comma-separated calendar IDs
 */
export function parseCalendarIds(calendarIdsParam?: string): string[] | undefined {
  if (!calendarIdsParam) return undefined;
  return calendarIdsParam.split(',').filter(id => id.trim().length > 0);
}
